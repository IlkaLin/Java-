package com.jyx.healthsys.mapper;
import com.jyx.healthsys.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
public interface RoleMapper extends BaseMapper<Role> {

    
}