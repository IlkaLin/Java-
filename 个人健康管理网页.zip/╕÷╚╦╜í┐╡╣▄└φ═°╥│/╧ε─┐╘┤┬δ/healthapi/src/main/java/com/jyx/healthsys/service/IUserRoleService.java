package com.jyx.healthsys.service;
import com.jyx.healthsys.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;
public interface IUserRoleService extends IService<UserRole> {

}
