package com.jyx.healthsys.mapper;
import com.jyx.healthsys.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
public interface UserRoleMapper extends BaseMapper<UserRole> {

    
}
