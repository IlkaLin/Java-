package com.jyx.healthsys.service;
import com.jyx.healthsys.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;
public interface IRoleMenuService extends IService<RoleMenu> {

}