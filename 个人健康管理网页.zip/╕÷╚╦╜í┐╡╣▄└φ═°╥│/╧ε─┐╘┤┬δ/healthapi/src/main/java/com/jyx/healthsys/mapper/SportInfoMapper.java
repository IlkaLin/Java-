package com.jyx.healthsys.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jyx.healthsys.entity.SportInfo;
import java.util.List;
public interface SportInfoMapper extends BaseMapper<SportInfo> {

    
}