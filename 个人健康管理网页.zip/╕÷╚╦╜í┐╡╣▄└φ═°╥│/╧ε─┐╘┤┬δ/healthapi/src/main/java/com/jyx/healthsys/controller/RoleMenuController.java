package com.jyx.healthsys.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
@Controller
@RequestMapping("/healthsys/roleMenu")
public class RoleMenuController {
}
