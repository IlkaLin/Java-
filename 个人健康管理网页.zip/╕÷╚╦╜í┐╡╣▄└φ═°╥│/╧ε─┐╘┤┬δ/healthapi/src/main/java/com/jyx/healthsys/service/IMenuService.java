package com.jyx.healthsys.service;
import com.jyx.healthsys.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;
public interface IMenuService extends IService<Menu> {
    List<Menu> getAllMenu();
    List<Menu> getMenuListByUserId(Integer userId);
}
