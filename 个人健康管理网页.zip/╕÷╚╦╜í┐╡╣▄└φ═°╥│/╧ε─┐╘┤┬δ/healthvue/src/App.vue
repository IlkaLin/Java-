<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
.app-main{
  padding: 10px;
  background-color: rgb(247, 250, 250);
}
.el-card{
  margin-bottom:15px;
}
</style>
